package unipi.eightpuzzle.utils;

/**
 * Simple int wrapper
 * @author Francesco Lorenzoni
 */
public class IntWrapper {
    public int value;
    public IntWrapper (int value){
        this.value = value;
    }
}
